using NUnit.Framework;
using System.Xml;
using TradeProcess;

namespace TestTradeProcess
{
    public class Tests
    {
        [SetUp]
        public void Setup()
        {

        }

        [Test]
        public void ProvidedTest()
        {
            TradeAggregator tradeAggregator = new TradeAggregator();
            XmlDocument doc = new XmlDocument();
            doc.LoadXml(@"<Trades>
	<Trade CorrelationId='234' NumberOfTrades='3' Limit='1000' TradeID='654'>100</Trade>
	<Trade CorrelationId='234' NumberOfTrades='3' Limit='1000' TradeID='135'>200</Trade>
	<Trade CorrelationId='222' NumberOfTrades='1' Limit='500' TradeID='423'>600</Trade>
	<Trade CorrelationId='234' NumberOfTrades='3' Limit='1000' TradeID='652'>200</Trade>
	<Trade CorrelationId='200' NumberOfTrades='2' Limit='1000' TradeID='645'>1000</Trade>
</Trades>");

            tradeAggregator.Aggregate(doc);
            Assert.AreEqual(tradeAggregator.AggregatedTradesRepository.Count,3);
            Assert.AreEqual(tradeAggregator.AggregatedTradesRepository["200"].TradeAggregationStatus, AggregationStatus.Pending);
            Assert.AreEqual(tradeAggregator.AggregatedTradesRepository["222"].TradeAggregationStatus, AggregationStatus.Rejected);
            Assert.AreEqual(tradeAggregator.AggregatedTradesRepository["234"].TradeAggregationStatus, AggregationStatus.Accepted);
        }

        [Test]
        public void AggregationOfTradesWithExceedLimit_Should_Return_Rejected()
        {
            TradeAggregator tradeAggregator = new TradeAggregator();
            XmlDocument doc = new XmlDocument();
            doc.LoadXml(@"<Trades>
	<Trade CorrelationId='234' NumberOfTrades='2' Limit='1000' TradeID='654'>1000</Trade>
	<Trade CorrelationId='234' NumberOfTrades='2' Limit='1000' TradeID='135'>200</Trade>
</Trades>");

            tradeAggregator.Aggregate(doc);
            Assert.AreEqual(tradeAggregator.AggregatedTradesRepository.Count, 1);
            Assert.AreEqual(tradeAggregator.AggregatedTradesRepository["234"].TradeAggregationStatus, AggregationStatus.Rejected);
        }

        [Test]
        public void AggregationOfTradesWithDuplicateTrade_Should_Return_Rejected()
        {
            TradeAggregator tradeAggregator = new TradeAggregator();
            XmlDocument doc = new XmlDocument();
            doc.LoadXml(@"<Trades>
	<Trade CorrelationId='234' NumberOfTrades='2' Limit='1000' TradeID='654'>100</Trade>
	<Trade CorrelationId='234' NumberOfTrades='2' Limit='1000' TradeID='135'>200</Trade>
	<Trade CorrelationId='234' NumberOfTrades='2' Limit='1000' TradeID='135'>200</Trade>
</Trades>");

            tradeAggregator.Aggregate(doc);
            Assert.AreEqual(tradeAggregator.AggregatedTradesRepository.Count, 1);
            Assert.AreEqual(tradeAggregator.AggregatedTradesRepository["234"].TradeAggregationStatus, AggregationStatus.Rejected);
        }

        [Test]
        public void AggregationOfTradesWithPendingTrade_Should_Return_Pending()
        {
            TradeAggregator tradeAggregator = new TradeAggregator();
            XmlDocument doc = new XmlDocument();
            doc.LoadXml(@"<Trades>
	<Trade CorrelationId='234' NumberOfTrades='3' Limit='1000' TradeID='654'>100</Trade>
	<Trade CorrelationId='234' NumberOfTrades='3' Limit='1000' TradeID='135'>200</Trade>
</Trades>");

            tradeAggregator.Aggregate(doc);
            Assert.AreEqual(tradeAggregator.AggregatedTradesRepository.Count, 1);
            Assert.AreEqual(tradeAggregator.AggregatedTradesRepository["234"].TradeAggregationStatus, AggregationStatus.Pending);
        }
    }
}