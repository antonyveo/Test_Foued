﻿using Serilog;
using System;

namespace TradeProcess
{
    class Program
    {
        static void Main(string[] args)
        {
            Log.Logger = new LoggerConfiguration()
                .WriteTo.File("server.log")
                .CreateLogger();

            Log.Information("Starting Trade Aggregation");

            TradeAggregator tradeAggregator = new TradeAggregator();

            if (tradeAggregator.LoadFromXml("input.xml"))
                tradeAggregator.PrintAggregatedTrades("results.csv");

            Log.Information("Aggregation End");
        }
    }
}
