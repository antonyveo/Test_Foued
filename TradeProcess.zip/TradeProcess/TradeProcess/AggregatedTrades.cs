﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TradeProcess
{
    public enum AggregationStatus { Pending,Accepted,Rejected}
    public class AggregatedTrades
    {
        public int NumberOfTardes { get; set; }

        public int Limit { get; set; }

        public int ValueSum { get; set; }

        public List<string> AggregatedTradeIds { get; set; }

        public AggregationStatus TradeAggregationStatus { get; set; }
    }

}
