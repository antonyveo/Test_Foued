﻿using CsvHelper;
using Serilog;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Text;
using System.Xml;

namespace TradeProcess
{
    public class TradeAggregator
    {
        //Sort will  be based on string sort because as described IDs are strings for example "1000" will be before "234"
        public SortedDictionary<string, AggregatedTrades> AggregatedTradesRepository { get; set; }

        public TradeAggregator()
        {
            AggregatedTradesRepository = new SortedDictionary<string, AggregatedTrades>();
        }

        private XmlDocument GetXmlFromFile(string filePath)
        {
            XmlDocument doc = new XmlDocument();

            try
            {
                doc.Load(filePath);
            }
            catch (FileNotFoundException)
            {
                Log.Fatal("File not found");
            }

            return doc;
        }

        public bool LoadFromXml(string filePath)
        {
            try
            {
                XmlDocument doc = GetXmlFromFile(filePath);
                Aggregate(doc);
            }
            catch (Exception)
            {
                return false;
            }

            return true;
        }

        public bool Aggregate(XmlDocument doc)
        {
            XmlNodeList elemList = doc.GetElementsByTagName("Trade");

            for (int i = 0; i < elemList.Count; i++)
            {
                try
                {
                    string correlationId = elemList[i].Attributes["CorrelationId"].Value;

                    int nbTrade = Int32.Parse(elemList[i].Attributes["NumberOfTrades"].Value);

                    int limit = Int32.Parse(elemList[i].Attributes["Limit"].Value); ;

                    string tradeID = elemList[i].Attributes["TradeID"].Value;

                    if (correlationId == String.Empty || tradeID == String.Empty)
                    {
                        Log.Error("CorrelationID/TradeID Empty for Trade:" + i + " => Trade ignored");
                        continue;
                    }

                    if (nbTrade <= 0)
                    {
                        Log.Error("NumberOfTrades less than zero for Trade:" + i + " => Trade ignored");
                        continue;
                    }
                    if (!elemList[i].HasChildNodes || elemList[i].ChildNodes.Count > 1)
                    {
                        Log.Error("Wrong Trade Value for Trade:" + i + " => Trade ignored");
                        continue;
                    }

                    int tradeValue = Int32.Parse(elemList[i].ChildNodes[0].Value);

                    if (!AggregatedTradesRepository.ContainsKey(correlationId))
                    {
                        AggregatedTradesRepository.Add(correlationId, new AggregatedTrades
                        {
                            NumberOfTardes = nbTrade,
                            Limit = limit,
                            ValueSum = tradeValue,
                            AggregatedTradeIds = new List<string> { tradeID },
                            TradeAggregationStatus = (tradeValue > limit) ? AggregationStatus.Rejected : (nbTrade == 1) ?
                                                            AggregationStatus.Accepted : AggregationStatus.Pending
                        });
                    }
                    else
                    {
                        if (AggregatedTradesRepository[correlationId].TradeAggregationStatus == AggregationStatus.Rejected)
                            continue;
                        if (AggregatedTradesRepository[correlationId].TradeAggregationStatus == AggregationStatus.Accepted)
                        {
                            AggregatedTradesRepository[correlationId].TradeAggregationStatus = AggregationStatus.Rejected;
                            continue;
                        }
                        if (AggregatedTradesRepository[correlationId].Limit != limit ||
                            AggregatedTradesRepository[correlationId].NumberOfTardes != nbTrade)
                        {
                            AggregatedTradesRepository[correlationId].TradeAggregationStatus = AggregationStatus.Rejected;
                            Log.Error("Anomaly detected on Group with CorrelationId[" + correlationId + "] because of anomaly on " +
                                "trade with ID[" + tradeID + "]=> Group will be rejected");
                            continue;
                        }
                        if (AggregatedTradesRepository[correlationId].AggregatedTradeIds.Contains(tradeID))
                        {
                            AggregatedTradesRepository[correlationId].TradeAggregationStatus = AggregationStatus.Rejected;
                            Log.Error("Anomaly detected on Group with CorrelationId[" + correlationId + "] because of  dupplicated " +
                                "trade with ID[" + tradeID + "]=> Group will be rejected");
                            continue;
                        }

                        AggregatedTradesRepository[correlationId].ValueSum += tradeValue;
                        AggregatedTradesRepository[correlationId].AggregatedTradeIds.Add(tradeID);
                        if (AggregatedTradesRepository[correlationId].ValueSum > limit)
                        {
                            AggregatedTradesRepository[correlationId].TradeAggregationStatus = AggregationStatus.Rejected;
                        }
                        else if (AggregatedTradesRepository[correlationId].AggregatedTradeIds.Count == nbTrade)
                        {
                            AggregatedTradesRepository[correlationId].TradeAggregationStatus = AggregationStatus.Accepted;
                        }
                    }
                }
                catch (ArgumentException)
                {
                    Log.Error("Bad attribute on Trade:" + i + " => Trade ignored");
                }
                catch (FormatException)
                {
                    Log.Error("Parsing Issue on Trade:" + i + " => Trade ignored");
                }
            }

            return true;
        }

        public void PrintAggregatedTrades(string filePath)
        {
            var csv = new StringBuilder();

            string header = "CorrelationID,NumberOfTrades,State";
            csv.AppendLine(header);

            foreach (var aggregatedTrade in AggregatedTradesRepository)
            {
                csv.AppendLine(aggregatedTrade.Key + ","
                    + aggregatedTrade.Value.NumberOfTardes + ","
                    + aggregatedTrade.Value.TradeAggregationStatus);
            }

            try
            {
                File.WriteAllText(filePath, csv.ToString());
            }
            catch (Exception e)
            {
                Log.Fatal("Exception on Writing File: " + e.Message);
            }
        }
    }
}
